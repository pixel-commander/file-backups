# Stamp Suite — install

Everything in one folder: the `repo-miner` auditing toolkit and the dashboard UI.

## Requirements

- **Node 18.17+** (`node -v`). Nothing else is mandatory.
- Windows, macOS or Linux. Paths are normalised to POSIX inside every record.

## One-shot install

Windows:

```bat
install.cmd
```

macOS / Linux:

```bash
./install.sh
```

That runs `npm install` in `repo-miner/`, builds, and runs the test suite.

## Manual install

```bash
cd repo-miner
npm install
npm run build     # optional — tsx runs the source directly
npm test
```

## First audit

```bash
cd repo-miner
npx repo-miner scan C:\src\my-app          # Windows
npx repo-miner scan ~/src/my-app            # macOS / Linux
```

The folder is registered as a **world** automatically and results land in:

```text
repo-miner/worlds/<world>/results/<stamp>/<numberstamp>/results.js
repo-miner/worlds/<world>/results/_runs/<numberstamp>/corpus.txt
```

`<numberstamp>` is a raw `Date.now()`.

Then:

```bash
npx repo-miner scan . --all             # every analyzer, including opt-ins
npx repo-miner worlds                   # list registered worlds
npx repo-miner analyzers                # all 15 analyzers and their groups
npx repo-miner stamps                   # installed stamps, props, on/off state
npx repo-miner stamps disable css-values
```

## Adding your own script

`automation/` maintains itself — no registration step, no central list.

```bash
cd repo-miner
node automation/__script-template/new-stamp.mjs count-hooks "Count hooks"
# edit automation/count-hooks/script.mjs   <- plain JS, no build
node automation/count-hooks/count-hooks.mjs C:\src\my-app
```

Drop a folder in and it is picked up on the next run; delete it and it is gone.
Set `enabled: false` in a stamp's `settings.js` (or use `repo-miner stamps
disable <slug>`) to keep the folder but skip the stamp. Its `props` become the
controls on the stamper page. The CLI refreshes `dashboard/generated-stamps.js`
automatically; `npx repo-miner stamps sync` forces a refresh manually.

## Optional external tools

Each is detected at runtime. Missing = that analyzer is **skipped, never fatal**.

| Tool | Adds | Install |
| --- | --- | --- |
| ripgrep | fast lexical patterns (falls back to in-process regex) | `winget install BurntSushi.ripgrep.MSVC` / `brew install ripgrep` |
| ast-grep | structural AST rules | `npm i -g @ast-grep/cli` |
| semgrep | architectural policy from `semgrep/*.yml` | `pip install semgrep` |
| knip | sharper dead-code detection | `cd repo-miner && npm i -D knip` |
| jscpd | copy-paste detection | `cd repo-miner && npm i -D jscpd` |
| git | churn, ownership, change coupling | already installed |

## Dashboard

`dashboard/Audit Dashboard.dc.html` opens directly in a browser — no build, no
server. It ships with mock results so every screen is explorable offline; the
CITY tab pulls three.js from a CDN, so that one view needs network access.

`dashboard/styles/` is the standalone atoms + elements CSS layer. `styles/README.md`
states the contract: atoms own rails/radius/background/shadow, elements own
grid/padding/type, composed as `class="container-main stamp-select-row"`.

## Layout

```text
stamp-suite/
  INSTALL.md
  install.cmd / install.sh
  repo-miner/
    bin/            CLI launcher
    src/            core, parsers, 15 analyzers, corpus writer, CLI
    automation/     one self-registering folder per stamp
      __script-template/   copy this to add your own
    tests/          15 test files
    config/         repo-miner.config.mjs template
    semgrep/        architectural rule pack
    ast-grep/       structural rule pack
    examples/       sample commands
    README.md       full toolkit documentation
  dashboard/
    Audit Dashboard.dc.html
    support.js
    styles/
```

Full analyzer reference, output contract and extension guide: `repo-miner/README.md`.
