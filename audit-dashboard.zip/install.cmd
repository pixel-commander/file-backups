@echo off
setlocal
echo.
echo   Stamp Suite installer
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo   [x] Node.js not found. Install Node 18.17+ from https://nodejs.org
  exit /b 1
)

for /f "tokens=*" %%v in ('node -v') do set NODEV=%%v
echo   node %NODEV%

cd /d "%~dp0repo-miner"

echo   installing dependencies...
call npm install --no-audit --no-fund || exit /b 1

echo   building...
call npm run build || echo   [!] build failed - tsx can still run the source

echo   running tests...
call npm test || echo   [!] some tests failed

node "%~dp0repo-miner\bin\sync-dashboard.mjs" >nul 2>nul

echo.
echo   Done. Try:
echo     cd repo-miner
echo     npx repo-miner scan C:\path\to\your\repo
echo.
echo   Dashboard: open dashboard\Audit Dashboard.dc.html
echo.
endlocal
