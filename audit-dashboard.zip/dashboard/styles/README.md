# CSS layer contract

Two layers, never mixed:

**atoms/** own rails only — border, border-radius, background, box-shadow, color.
An atom NEVER declares padding, margin, display, grid, gap, or width.

**elements/** own structure only — display, grid/flex, gap, padding, font-size,
letter-spacing, text-align. An element NEVER declares background, border, or radius.

Compose by putting one atom and one element on the same node:

    <button class="container-main stamp-select-row">…</button>
    <button class="container-main selected stamp-select-row">…</button>
    <div class="row-alt table-head">…</div>
    <button class="btn-accent stamp-select-row">…</button>

Modifiers on atoms are additional classes, not new atoms:
`container-main inset`, `container-main float`, `container-main surface`,
`container-main accent`, `container-main selected`.

If a grid does not exist yet, add it to elements/ — never widen an atom to fit it.

Load order: tokens.css → atoms/* → elements/*
