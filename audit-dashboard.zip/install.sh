#!/usr/bin/env bash
set -u

printf '\n  Stamp Suite installer\n\n'

if ! command -v node >/dev/null 2>&1; then
  printf '  [x] Node.js not found. Install Node 18.17+ from https://nodejs.org\n'
  exit 1
fi

printf '  node %s\n' "$(node -v)"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/repo-miner" || exit 1

printf '  installing dependencies...\n'
npm install --no-audit --no-fund || exit 1

printf '  building...\n'
npm run build || printf '  [!] build failed - tsx can still run the source\n'

printf '  running tests...\n'
npm test || printf '  [!] some tests failed\n'

printf '\n  Done. Try:\n    cd repo-miner\n    npx repo-miner scan ~/path/to/your/repo\n'
node "$SCRIPT_DIR/repo-miner/bin/sync-dashboard.mjs" || true
printf '\n  Dashboard: open "dashboard/Audit Dashboard.dc.html"\n\n'
