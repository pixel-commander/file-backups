# Fix pass — August 25, 2026

This package was patched after a code review of the repo-miner + audit dashboard.

## Fixed

- Dashboard stamp registry is generated from `automation/*/settings.js`; drop/remove a stamp folder and the UI registry follows it.
- Stamp prop schemas now generate generic dashboard controls and flow into copied config output.
- Stamp prop precedence is now: settings defaults < config file < runtime/CLI overrides.
- Component inventory conditional-hook option no longer fails from variable shadowing.
- Component parsing now covers named/anonymous default exports, `React.memo` / `forwardRef`, referenced props types, same-file component dependencies, and avoids PascalCase helper false positives without React evidence.
- Component dependents are finalized before corpus/result serialization.
- Git history is scoped correctly when auditing a nested package inside a monorepo.
- Optional external tools must actually be installed locally/on PATH; the auto-detection path no longer treats `npx` itself as proof that a tool exists.
- Streamed oversized files retain an accurate LOC count without retaining source text in memory.
- `latest.json` points to the output format that was actually emitted.
- CLI stamp scaffolding is script-backed and auto-discovered by default; no central registry edit is required.
- Added `repo-miner stamps sync` / `npm run sync-dashboard` and install-time dashboard registry refresh.

## Validation performed

- Strict TypeScript typecheck: passed.
- JS/MJS syntax checks across automation + bin: passed.
- TypeScript transpile syntax check: 57 files passed.
- Dashboard inline JavaScript + generated registry syntax: passed.
- Shell installer syntax: passed.
- Dynamic UI registry test: 15 -> 16 -> 15 stamps; generated prop schema verified.
- Targeted runtime/integration checks passed for component edge cases, conditional hooks, config precedence, streamed LOC, nested-monorepo Git scoping, result finalization, scaffold discovery, and external-tool detection.

The packaged Vitest suite was not run end-to-end in the repair sandbox because dependency installation timed out. The project now contains 15 Vitest test files, including regression tests for the repaired paths.
